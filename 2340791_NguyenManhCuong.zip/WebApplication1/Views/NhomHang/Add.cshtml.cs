using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.NhomHang
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
